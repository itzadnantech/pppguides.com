
    <div class="wrapper fadeInDown">
  <div id="formContent">
        <!-- Tabs Titles -->
        <!-- Icon -->
        <div class="fadeIn first">
            <h2>Terms and Conditions </h2>
      
        </div> 
   

        <div class="termsdetailslogin termsdetails" style="margin: 10px; margin-bottom:40px;" >

            <?php echo $terms?>
        </div>
        
        
        <div id="formFooter" class="loginspace" >
            <a class="underlineHover"  href="<?php echo base_url()?>user/login">OK</a>
        </div>
    </div>

  
</div>

</div>



