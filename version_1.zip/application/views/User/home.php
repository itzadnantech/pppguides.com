<?php $this->load->view('User/sidebar');?>

<a href="<?php echo base_url()?>user/companyInfo" class="startbox">
<div class="row start">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xm-12">
       <h1 class="startheading"><?php echo $value?> <i class="fa fa-long-arrow-right" aria-hidden="true"></i></h1> 
    </div>

</div> 
</a>



