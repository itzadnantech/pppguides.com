<?php
defined('BASEPATH') OR exit('No direct script access allowed');

        $config['base_url'] = 'http://digitalwebmark.com/pppforms';
?>
<!DOCTYPE html>
<html lang="en">
<?php
//header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
//header("Cache-Control: post-check=0, pre-check=0", false);
//header("Pragma: no-cache");
?>

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" type="image/x-icon" href="">
<title>Dashboard</title>
    
 <link type="text/css" href="<?php echo base_url();?>assets/css/fontawesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
<link rel=stylesheet href="<?php echo base_url();?>assets/css/style.css">
<link rel=stylesheet href="<?php echo base_url();?>assets/css/mobile.css">
<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
</head>

<body>

         
                