<style>
    <?php
        
    echo "\n\n /*style css*/ \n\n";
    include getcwd()."/assets/css/style.css";
    include getcwd()."/assets/css/developer.css";
    ?>
</style>