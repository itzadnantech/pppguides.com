<div  style="max-width:800px; margin-top:60px;" class="container-fluid  formcon">
    <div class="row sk_headings">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <h2>Personal Information </h2>

        </div>

    </div>

    <div class="border" style="margin-top: 20px;">
        <div class="row " style="text-align: center;">
            <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                <h3 class="subheading"  >You are almost there</h3>
            </div>
        </div>
        <div class="row " style="text-align: center;">
            <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                <h5 class="subheading">Please Continue providing key data under “Payroll Costs”, “Non-Payroll Costs” and “Safe Harbor” sections</h5>
                <a type="button" href="<?Php echo base_url()?>user/pricing" id="saveBtn1" class="btn_default">ok </a>
            </div>
        </div>
    </div>
</div>