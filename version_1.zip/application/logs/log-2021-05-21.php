<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-21 05:06:09 --> 404 Page Not Found: Faviconico/index
