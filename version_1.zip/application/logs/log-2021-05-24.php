<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-24 05:01:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-24 05:02:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-24 05:02:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-24 05:02:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-24 06:29:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-24 07:25:16 --> 404 Page Not Found: Faviconico/index
