<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-23 09:14:36 --> 404 Page Not Found: Faviconico/index
