<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-28 04:29:23 --> 404 Page Not Found: Faviconico/index
