<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-01 05:24:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-01 05:28:37 --> Severity: Notice --> Undefined variable: selectedmenu /home/w1ft43q4sr3u/public_html/pppguides/application/views/User/sidebar.php 52
ERROR - 2021-02-01 08:05:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-01 08:07:19 --> Severity: Notice --> Undefined variable: selectedmenu /home/w1ft43q4sr3u/public_html/pppguides/application/views/User/sidebar.php 52
