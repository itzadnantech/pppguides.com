<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-22 09:29:56 --> 404 Page Not Found: Faviconico/index
