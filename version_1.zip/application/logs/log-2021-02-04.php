<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-04 05:16:59 --> 404 Page Not Found: Robotstxt/index
