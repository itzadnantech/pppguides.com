<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-25 17:46:39 --> 404 Page Not Found: Faviconico/index
