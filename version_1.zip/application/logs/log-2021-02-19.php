<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-19 04:20:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 05:49:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 06:01:32 --> 404 Page Not Found: Faviconico/index
