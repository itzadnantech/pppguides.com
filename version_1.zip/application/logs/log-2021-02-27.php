<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-27 14:13:56 --> 404 Page Not Found: Faviconico/index
