<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-27 06:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-27 06:28:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-27 06:42:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-27 10:13:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-27 17:13:04 --> 404 Page Not Found: Faviconico/index
