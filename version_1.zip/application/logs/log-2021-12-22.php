<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-22 17:42:24 --> 404 Page Not Found: Faviconico/index
