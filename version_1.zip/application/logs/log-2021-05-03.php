<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 15:28:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-03 19:35:45 --> 404 Page Not Found: Faviconico/index
