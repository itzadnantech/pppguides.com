<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-14 06:01:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-14 06:02:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-14 07:12:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-14 10:04:54 --> 404 Page Not Found: Faviconico/index
