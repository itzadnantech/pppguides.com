<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:21:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:44:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:13:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:21:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:30:39 --> 404 Page Not Found: Faviconico/index
