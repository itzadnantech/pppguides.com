<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-05 04:25:14 --> 404 Page Not Found: Faviconico/index
