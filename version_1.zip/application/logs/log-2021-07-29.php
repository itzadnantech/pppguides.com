<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-29 04:08:00 --> 404 Page Not Found: Faviconico/index
