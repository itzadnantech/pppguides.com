<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-14 08:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:34:06 --> 404 Page Not Found: Faviconico/index
