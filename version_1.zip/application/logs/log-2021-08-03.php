<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-03 13:42:10 --> 404 Page Not Found: Faviconico/index
