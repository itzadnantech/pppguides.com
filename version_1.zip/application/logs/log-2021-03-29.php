<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-29 06:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-29 06:59:16 --> 404 Page Not Found: Faviconico/index
