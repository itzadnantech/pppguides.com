<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-12 06:06:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-12 06:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-12 06:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-12 06:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-12 16:50:36 --> 404 Page Not Found: Faviconico/index
