<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-03 04:05:49 --> 404 Page Not Found: Faviconico/index
