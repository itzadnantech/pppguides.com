<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-22 03:37:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 04:42:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 10:18:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 10:28:55 --> 404 Page Not Found: Faviconico/index
