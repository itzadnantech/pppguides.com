<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-23 05:03:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-23 06:21:09 --> 404 Page Not Found: Faviconico/index
