<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-31 10:03:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-31 10:05:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-31 15:24:20 --> 404 Page Not Found: Faviconico/index
