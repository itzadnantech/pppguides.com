<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-16 04:24:21 --> 404 Page Not Found: Faviconico/index
