<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-03 05:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 07:36:48 --> 404 Page Not Found: Faviconico/index
