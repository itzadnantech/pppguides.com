<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-20 18:07:40 --> 404 Page Not Found: Faviconico/index
