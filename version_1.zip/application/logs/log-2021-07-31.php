<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-31 04:23:25 --> 404 Page Not Found: Faviconico/index
