<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-04 06:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-04-04 07:00:07 --> 404 Page Not Found: Faviconico/index
