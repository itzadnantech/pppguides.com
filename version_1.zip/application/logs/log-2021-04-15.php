<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-15 08:53:33 --> 404 Page Not Found: Faviconico/index
