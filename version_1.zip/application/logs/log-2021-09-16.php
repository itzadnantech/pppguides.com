<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-16 06:22:13 --> 404 Page Not Found: Faviconico/index
