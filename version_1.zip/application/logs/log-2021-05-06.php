<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-06 05:30:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-06 06:09:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-06 06:10:44 --> Severity: Notice --> Undefined variable: selectedmenu /home/w1ft43q4sr3u/public_html/pppguides/application/views/User/sidebar.php 52
