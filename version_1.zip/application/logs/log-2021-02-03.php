<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-03 12:50:36 --> 404 Page Not Found: Faviconico/index
