<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 15:24:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-28 15:32:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-28 15:33:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-28 15:33:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-28 15:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-28 17:19:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-28 17:34:55 --> 404 Page Not Found: Faviconico/index
