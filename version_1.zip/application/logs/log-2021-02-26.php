<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-26 20:55:47 --> 404 Page Not Found: Faviconico/index
