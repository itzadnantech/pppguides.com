<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-19 06:11:23 --> 404 Page Not Found: Faviconico/index
